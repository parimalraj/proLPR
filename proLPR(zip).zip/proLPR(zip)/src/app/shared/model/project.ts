export class Project{
    projectId:string;

}